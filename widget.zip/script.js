define(['jquery', 'underscore', 'twigjs'], function ($, _, Twig) {
  var CustomWidget = function () {
    var self = this;

    const teletypeHost = 'https://panel.teletypeapp.com';

    const observer = new MutationObserver(function (mutations) {
      mutations.forEach(mutation => {
        if (!mutation.addedNodes) return
        mutation.addedNodes.forEach(node => {
          if (node.attributes && node.attributes['data-source-origin'] && waOrigins.includes(node
              .attributes['data-source-origin'].value)) {
            hideWriteButton(node, mutation);
          }
        });
      });
    });

    this.callbacks = {
      render: function () {
        if (typeof (AMOCRM.data.current_card) != 'undefined') {
          if (AMOCRM.data.current_card.linked_forms) {
            AMOCRM.data.current_card.linked_forms.form_views.forEach(view => {
              observer.observe(view.$el.context, {
                childList: true,
                subtree: true
              });
            });
          }
          if (AMOCRM.data.current_card.id == 0 || AMOCRM.data.current_entity === 'contacts') return false;
        }
        self.render_template({
          body: '',
          caption: {
            class_name: 'amo_teletype-widget-body'
          },
          render: ''
        }, {})
        $('div.amo_teletype-widget-body').css('background-color', '#0a86f9');
        const notesWrapper = document.querySelector('div.js-card-feed.card-holder__feed > .notes-wrapper');
        if (notesWrapper && !notesWrapper.classList.contains('wzFrameContainer')) notesWrapper.classList.add(
          'wzFrameContainer');
        return true;
      },
      init: _.bind(function () {
        //console.log('init');

        AMOCRM.addNotificationCallback(self.get_settings().widget_code, function (data) {
          //console.log(data)
        });

        this.add_action("phone", function (params) {
          /**
           * код взаимодействия с виджетом телефонии
           */
          //console.log(params)
        });

        this.add_source("sms", function (params) {
          /**
           params - это объект в котором будут  необходимые параметры для отправки смс

           {
             "phone": 75555555555,   // телефон получателя
             "message": "sms text",  // сообщение для отправки
             "contact_id": 12345     // идентификатор контакта, к которому привязан номер телефона
          }
           */

          return new Promise(_.bind(function (resolve, reject) {
            // тут будет описываться логика для отправки смс
            self.crm_post(
              'https://example.com/',
              params,
              function (msg) {
                //console.log(msg);
                resolve();
              },
              'text'
            );
          }, this));
        });

        return true;
      }, this),
      bind_actions: function () {
        $('div.amo_teletype-widget-body').on('click', function (e) {

          e.preventDefault();
          e.stopImmediatePropagation();

          // при нажатии на виджет teletype справа на панели в сделке открывается подраздел "Написать в Whatsapp"
          $('.mgc-template-modal').remove();

          const cardCustomFields = AMOCRM.data.current_card.linked_forms.form_views.reduce((cardFields,
            view) => {
            if (!view.entity) return cardFields;
            const entityCustomFields = Object.keys(view.model.attributes).reduce((entityFields,
              key) => {
              if (!key.startsWith('CFV') || key.endsWith('DESCRIPTION]') || view.model.attributes[
                  key] === '') return entityFields;
              const fieldId = key.match(/CFV\[(\d+)]/)[1];
              const name = (AMOCRM.constant('account').cf[fieldId] || Object.values(AMOCRM
                .constant('account').predefined_cf).find(cf => +cf.ID === +fieldId)).NAME
              return [...entityFields, {
                [fieldId]: {
                  id: fieldId,
                  name,
                  value: view.model.attributes[key]
                }
              }];
            }, []);
            return [...cardFields, ...entityCustomFields];
          }, []);

          const userCustomFieldsIds = Object.keys(AMOCRM.constant('account').cf);
          const phoneCustomFieldId = AMOCRM.constant('account').predefined_cf.PHONE.ID;

          const userCustomFields = cardCustomFields.reduce((acc, cf) => userCustomFieldsIds.some(id => cf[
            id]) ? {
            ...acc,
            ...cf
          } : acc, {});
          const phones = cardCustomFields.reduce((phones, cf) => cf[phoneCustomFieldId] ? [...phones, cf[
            phoneCustomFieldId].value] : phones, []);

          openChatInCard(phones, userCustomFields);
          return true;
        });

        $('.nav__menu__item__icon-integration[data-widget-code="teletype_dev"]').on('click', function(e) {
          e.preventDefault();
          e.stopImmediatePropagation();

          startChat(null, {
            amojoId: AMOCRM.constant('account').amojo_id,
            body: {
              operator_id: AMOCRM.constant('user').amojo_id
            }
          });
          return false
        });

        return false;
      },
      settings: function () {
        return true;
      },
      onSave: function () {
        return true;
      },
      destroy: function () {

      },
      contacts: {
        //select contacts in list and clicked on widget name
        selected: function () {
          // console.log('contacts');
        }
      },
      leads: {
        //select leads in list and clicked on widget name
        selected: function () {
          // console.log('leads');
        }
      },
      tasks: {
        //select taks in list and clicked on widget name
        selected: function () {
          // console.log('tasks');
        }
      },
      advancedSettings: _.bind(function () {
        var $work_area = $('#work-area-' + self.get_settings().widget_code),
          $save_button = $(
            Twig({
              ref: '/tmpl/controls/button.twig'
            }).render({
              text: 'Сохранить',
              class_name: 'button-input_blue button-input-disabled js-button-save-' + self.get_settings()
                .widget_code,
              additional_data: ''
            })
          ),
          $cancel_button = $(
            Twig({
              ref: '/tmpl/controls/cancel_button.twig'
            }).render({
              text: 'Отмена',
              class_name: 'button-input-disabled js-button-cancel-' + self.get_settings().widget_code,
              additional_data: ''
            })
          );

        $save_button.prop('disabled', true);
        $('.content__top__preset').css({
          float: 'left'
        });

        $('.list__body-right__top').css({
            display: 'block'
          })
          .append('<div class="list__body-right__top__buttons"></div>');
        $('.list__body-right__top__buttons').css({
            float: 'right'
          })
          .append($cancel_button)
          .append($save_button);
      }, self),

      initMenuPage: _.bind(function (params) {
        switch (params.location) {
          case 'stats': // в этом случае item_code, мы не получим
            switch (params.subitem_code) {
              case 'sub_item_1':
                self.getTemplate(
                  'stats__sub_item_1', {},
                  function (template) {
                    $('#work-area-' + self.get_settings().widget_code).html(
                      'Пункт Аналитика, подпункт 1');
                  });
                break;
              case 'sub_item_2':
                self.getTemplate(
                  'stats__sub_item_2', {},
                  function (template) {
                    $('#work-area-' + self.get_settings().widget_code).html(
                      'Пункт Аналитика, подпункт 2');
                  });
                break;
            }
            break;
          case 'settings': // в этом случае item_code, мы не получим
            // noop
            break;
          case 'widget_page':
            switch (params.item_code) {
              case 'custom_item_3':
                switch (params.subitem_code) {
                  case 'sub_item_1':
                    self.getTemplate(
                      'custom_item_3__sub_item_1', {},
                      function (template) {
                        $('#work-area-' + self.get_settings().widget_code).html('Пункт 3, подпункт 1');
                      });
                    break;
                    // etc.
                }
                break;
                // etc.
            }
            break;
        }
      }, self),

      /**
       * Метод срабатывает, когда пользователь в конструкторе Salesbot размещает один из хендлеров виджета.
       * Мы должны вернуть JSON код salesbot'а
       *
       * @param handler_code - Код хендлера, который мы предоставляем. Описан в manifest.json, в примере равен handler_code
       * @param params - Передаются настройки виджета. Формат такой:
       * {
       *   button_title: "TEST",
       *   button_caption: "TEST",
       *   text: "{{lead.cf.10929}}",
       *   number: "{{lead.price}}",
       *   url: "{{contact.cf.10368}}"
       * }
       *
       * @return {{}}
       */
      onSalesbotDesignerSave: function (handler_code, params) {
        var salesbot_source = {
            question: [],
            require: []
          },
          button_caption = params.button_caption || "",
          button_title = params.button_title || "",
          text = params.text || "",
          number = params.number || 0,
          handler_template = {
            handler: "show",
            params: {
              type: "buttons",
              value: text + ' ' + number,
              buttons: [
                button_title + ' ' + button_caption,
              ]
            }
          };

        salesbot_source.question.push(handler_template);

        return JSON.stringify([salesbot_source]);
      },
    };

    function openChatInCard(phones, userCustomFields) {
      if (!AMOCRM.data.card_page) return;
      startChat(phones, {
        amojoId: AMOCRM.constant('account').amojo_id,
        body: {
          operator_id: AMOCRM.constant('user').amojo_id,
            lead_id: AMOCRM.data.current_card.id,
        }
      });
    }

    async function startChat(phone, meta) {
      try {
        const account = Object.assign({}, AMOCRM.constant('account'));
        delete account.cf;
        delete account.predefined_cf;

        const credentials = await teletypeRequest({
          path: `api/v1/amo-crm/widget-data/${meta.amojoId}`,
          body: meta.body
        });

        if (credentials.success) {

        } else {
          showMessageInAMONotifications(self.i18n('messages.networkError'), 'error');
          return false;
        }

        const debug = true;

        const bestChoice = meta.body.lead_id ? credentials.data.find(d => d.appeal !== null) : credentials.data[0];

        const project = bestChoice.project;
        const client = bestChoice.client;
        const appeal = bestChoice.appeal;
        const person = bestChoice.person;
        const token = bestChoice.token;

        const domain = debug ? 'http://localhost:4200' : project.url;

        let link = '';

        if (!meta.body.lead_id) {
          link =
          `${domain}/api-conversations/open/open?authToken=${token}&single=false&project=${encodeURIComponent(utf8_to_b64(JSON.stringify(project)))}&client=${encodeURIComponent(utf8_to_b64(JSON.stringify(client)))}`;
        } else {
          link =
          `${domain}/api-conversations/${appeal.channelId}/open?authToken=${token}&appealId=${appeal.items[0].appeal_id}&single=true&project=${encodeURIComponent(utf8_to_b64(JSON.stringify(project)))}&client=${encodeURIComponent(utf8_to_b64(JSON.stringify(client)))}`;
        }

        showIFrame(link, (!phone || phone !== 'global'));
      } catch(e) {
        showMessageInAMONotifications(self.i18n('messages.networkError'), 'error');
      }
    }

    function utf8_to_b64(str) {
      return window.btoa(unescape(encodeURIComponent(str)));
    }

    function b64_to_utf8(str) {
      return decodeURIComponent(escape(window.atob(str)));
    }

    async function teletypeRequest({
      path,
      method = 'post',
      body
    }) {
      return await fetch(`${teletypeHost}/${path}`, {
        method,
        cache: 'no-cache',
        headers: {
          'Content-Type': method === 'post' ? 'application/x-www-form-urlencoded' : 'application/json'
        },
        body: method === 'post' ? new URLSearchParams(body) : JSON.stringify(body)
      }).then(res => res.json());
    }

    function showMessageInAMONotifications(text, level) {
      const func = level === 'error' ? 'add_error' : 'show_message';
      AMOCRM.notifications[func]({
        header: 'Teletype',
        text,
        date: new Date()
      });
    }

    function showIFrame(html, intoCard) {
      let progress = 0;
      let direction = 'open';
      let isGlobal = true;

      let iframeContainer = document.body;
      if (intoCard && document.querySelector('div.js-card-feed.card-holder__feed')) {
        if (iframeContainer.querySelector('.wzFrameContainer')) {
          iframeContainer = document.querySelector('div.js-card-feed.card-holder__feed');
          iframeContainer.querySelector('.wzFrameContainer').style.visibility = 'hidden';
          isGlobal = false;
        }
      }

      let oldIframe = document.querySelector('iframe#teletype');
      if (oldIframe) {
        try {
          let div = oldIframe.parentElement;
          let div0 = div.parentElement;
          let iframeContainer = div0.parentElement;
          iframeContainer.removeChild(div0);
          if (iframeContainer.querySelector('.wzFrameContainer')) {
            iframeContainer.querySelector('.wzFrameContainer').style.visibility = 'visible';
          }
        } catch (e) {
          //console.debug(e);
        }
      }


      let div0 = document.createElement('div');
      let divBg = document.createElement('div');
      let div = document.createElement('div');
      let iframe = document.createElement('iframe');
      let divSVG = document.createElement('div');

      function transformation() {
        if (progress == 1) {
          div0.removeChild(divSVG);
        }
        progress += ((direction == 'open') ? 1 : -1) * 0.12;
        if (progress > 1) progress = 1;
        if (progress < 0) progress = 0;
        div.style.setProperty('right', '-' + (div.clientWidth * (1 - progress)) + 'px');
        if ((progress > 0) && (progress < 1)) setTimeout(transformation, 40);
        if (progress == 0) {
          iframeContainer.removeChild(div0);
          if (!isGlobal) {
            iframeContainer.querySelector('.wzFrameContainer').style.visibility = 'visible';
          }
        } else if (progress == 1) {
          div0.appendChild(divSVG);
          divSVG.querySelector('svg').addEventListener('click', () => {
            direction = 'close';
            setTimeout(transformation, 40);
          });
        }
      }

      div0.style.setProperty('position', isGlobal ? 'fixed' : 'static');
      div0.style.setProperty('left', 0);
      div0.style.setProperty('right', 0);
      div0.style.setProperty('top', 0);
      div0.style.setProperty('bottom', 0);
      div0.style.setProperty('height', '100%');
      div0.style.setProperty('width', '100%');
      div0.style.setProperty('z-index', '999999');

      iframeContainer.appendChild(div0);

      divSVG.innerHTML =
        '<svg fill="#ffffff" height="48" viewBox="0 0 24 24" width="48" xmlns="http://www.w3.org/2000/svg" style="float: right; cursor:pointer;"><path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg>';
      divSVG.style.setProperty('position', 'absolute');
      divSVG.style.setProperty('z-index', '9999999');
      divSVG.style.setProperty(isGlobal ? 'left' : 'right', 0);
      divSVG.style.setProperty('top', '5px');
      divSVG.style.setProperty('width', '180px');

      divBg.style.setProperty('position', 'absolute');
      divBg.style.setProperty('left', 0);
      divBg.style.setProperty('right', 0);
      divBg.style.setProperty('top', 0);
      divBg.style.setProperty('bottom', 0);
      divBg.style.setProperty('height', '100%');
      divBg.style.setProperty('width', '100%');
      divBg.style.setProperty('opacity', 0.4);
      divBg.style.setProperty('background', 'black');
      divBg.addEventListener('click', () => {
        direction = 'close';
        setTimeout(transformation, 40);
      });
      div0.appendChild(divBg);

      div.style.setProperty('position', 'absolute');
      div.style.setProperty('bottom', 0);
      div.style.setProperty('height', isGlobal ? '100%' : 'calc(100% - 60px)');
      div.style.setProperty('width', isGlobal ? 'calc(100% - 200px)' : '100%');
      div.style.setProperty('z-index', '9999999');


      iframe.id = 'teletype';
      iframe.style.setProperty('height', '100%');
      iframe.style.setProperty('width', '100%');
      iframe.setAttribute('allowfullscreen', '');

      div0.appendChild(div);
      div.style.setProperty('right', '-' + (div.clientWidth) + 'px');

      iframe.src = html;
      div.appendChild(iframe);

      setTimeout(transformation, 40);
    }

    function createIFrame(html) {
      let isGlobal = true;

      let iframeContainer = document.body;

      let oldIframe = document.querySelector('iframe#teletype');
      if (oldIframe) {
        try {
          let div = oldIframe.parentElement;
          let div0 = div.parentElement;
          let iframeContainer = div0.parentElement;
          iframeContainer.removeChild(div0);
          if (iframeContainer.querySelector('.wzFrameContainer')) {
            iframeContainer.querySelector('.wzFrameContainer').style.visibility = 'visible';
          }
        } catch (e) {
          //console.debug(e);
        }
      }

      let iframe = document.createElement('iframe');

      iframe.id = 'teletype';
      iframe.style.setProperty('height', '100%');
      iframe.style.setProperty('width', '100%');
      iframe.setAttribute('allowfullscreen', '');

      iframe.src = 'data:text/html;charset=utf-8,' + encodeURIComponent(html);
      return iframe;
    }

    return this;
  };

  return CustomWidget;
});
