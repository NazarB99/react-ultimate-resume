# amocrm-widget
Наш внутренний виджет внутри amoCRM

# Дебаг виджета
1. Запустить панель локально
2. В файле ```script.js``` найти строку ```const debug = false ``` и изменить значение на ```true```
3. Сформировать архив
4. Отправить в teletype_dev(https://pamoteletypeapp.amocrm.ru/settings/widgets/)